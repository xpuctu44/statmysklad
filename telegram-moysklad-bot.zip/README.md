## Телеграм-бот на python-telegram-bot

### Что умеет
- **/start**: приветствие
- **/help**: список команд
- **Эхо**: отвечает тем же текстом

### Быстрый старт (Windows)
1) Установите Python 3.10+
2) Создайте бота у `@BotFather` и получите `BOT_TOKEN`
3) Скопируйте `tgbot/env.sample` в `tgbot/.env` и вставьте токен
4) В терминале выполните:
```bash
cd tgbot
python -m venv .venv
./.venv/Scripts/python -m pip install -U pip
./.venv/Scripts/python -m pip install -r requirements.txt
./.venv/Scripts/python bot.py
```

### Переменные окружения
Файл `.env`:
```
BOT_TOKEN=123456789:ABCDEF_your_token
# --- МойСклад ---
# Вариант 1 (предпочтительно):
# MOYSKLAD_TOKEN=your_token
# Или вариант 2:
# MOYSKLAD_LOGIN=your_login@example.com
# MOYSKLAD_PASSWORD=your_password_or_app_password
```

### Примечания
- Храните токен в `.env`, не публикуйте его
- Для продакшена используйте вебхуки и хостинг/сервер

### Команды интеграции с МойСклад
- `/ms_products <поиск>` — найдёт до 5 товаров по строке поиска (если не указан текст — покажет первые 5 товаров)



